<?php
$host="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="formphp";


$mysqli =mysqli_connect($host,$dbUsername,$dbPassword,$dbName);

?>